# Klarzo
A mental wellness platform powered by AI.