
import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import FeatureCards from './components/FeatureCards';

const App = () => (
  <div>
    <Navbar />
    <HeroSection />
    <FeatureCards />
  </div>
);

export default App;
