
import React from 'react';

const HeroSection = () => (
  <section className="text-center py-20 bg-gradient-to-b from-blue-100 to-white">
    <h1 className="text-5xl font-bold text-blue-900 mb-4">Welcome to Klarzo</h1>
    <p className="text-lg text-gray-700 max-w-2xl mx-auto">An AI-powered platform to help you relax, heal, and grow. Choose your path to peace.</p>
  </section>
);

export default HeroSection;
