
import React from 'react';

const Navbar = () => (
  <nav className="bg-white shadow-md p-4 flex justify-between items-center">
    <div className="text-xl font-bold text-blue-800">Klarzo</div>
    <ul className="flex space-x-6">
      <li><a href="#" className="text-gray-700 hover:text-blue-600">Home</a></li>
      <li><a href="#" className="text-gray-700 hover:text-blue-600">About</a></li>
      <li><a href="#" className="text-gray-700 hover:text-blue-600">Relax</a></li>
      <li><a href="#" className="text-gray-700 hover:text-blue-600">Connect</a></li>
    </ul>
  </nav>
);

export default Navbar;
