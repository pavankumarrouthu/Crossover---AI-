
import React from 'react';

const features = [
  { title: "Meditation", desc: "Guided sessions to help you find peace." },
  { title: "AI Listener", desc: "Talk your heart out to our AI companion." },
  { title: "Mood Tracker", desc: "Track and understand your emotional patterns." }
];

const FeatureCards = () => (
  <div className="py-16 px-8 grid md:grid-cols-3 gap-8">
    {features.map((f, i) => (
      <div key={i} className="p-6 bg-white rounded-2xl shadow-lg text-center">
        <h3 className="text-xl font-semibold mb-2">{f.title}</h3>
        <p className="text-gray-600">{f.desc}</p>
      </div>
    ))}
  </div>
);

export default FeatureCards;
